package ru.gb.catch_the_drop.lession_2_1;

import java.awt.*;
import java.util.Random;

public class Ball extends Sprite{
    Random rnd = new Random();
//    private final Color color = new Color( // Рандомим цвет
//            (int)(Math.random() * 255),
//            (int)(Math.random() * 255),
//            (int)(Math.random()* 255)
//    );
    private final Color color;
    private float vX; // Скорость
    private float vY;

    Ball(){
         halfHeight = 20 + (float)(Math.random() * 50f); //Устанавилваем высоту шарика от 20 до 70px
         halfWidth = halfHeight; // Устанавливаем ширину шарика
        color = new Color(rnd.nextInt());
        vX = (float)(100f + (Math.random()* 200f)); // Скорость
         vY = (float)(100f + (Math.random()* 200f)); // Скорость
    }

    @Override
    void update(GameCanvas canvas, float deltaTime) {
        x += vX * deltaTime; // Смещение ball по координатам
        y += vY * deltaTime; // Смещение ball по координатам

        if (getLeft() < canvas.getLeft()) {    //Если левая часть sprite коснулась левую часть канвы
            setLeft(canvas.getLeft());         //Устанавливаем левую часть sprite в левую границу канвы
            vX = -vX;                          //Изменяем направление
        }
        if (getRight() > canvas.getRight()) {
            setRight(canvas.getRight());
            vX = -vX;
        }
        if (getTop() < canvas.getTop()) {
            setTop(canvas.getTop());
            vY = -vY;
        }
        if (getBottom() > canvas.getBottom()) {
            setBottom(canvas.getBottom());
            vY = -vY;
        }
    }
    @Override
    void render(GameCanvas canvas, Graphics g) {
        g.setColor(color);  // Рисуем цвет
        g.fillOval((int) getLeft(), (int)getTop(), // Рисуем размер ?
                (int)getWidth(), (int)getHeight());
    }
}
