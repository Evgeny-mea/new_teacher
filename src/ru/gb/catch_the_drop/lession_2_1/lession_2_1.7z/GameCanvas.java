package ru.gb.catch_the_drop.lession_2_1;

import javax.swing.*;
import java.awt.*;

public class GameCanvas extends JPanel {

    long lastFrameTime; //Константа времени
    MainCircles controller; // ?????

    GameCanvas(MainCircles controller) { // Что мы сюда передаем, от куда взялся контроллер ?
        lastFrameTime = System.nanoTime(); // Присваиваем константе текущее время
        this.controller = controller; // Тоже не очень понятно
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        long currentTime = System.nanoTime(); // Создаем лонг значение для переопределения (текущее время)
        float deltaTime = (currentTime - lastFrameTime) * 0.000000001f; // Вычесляем дельту
        System.out.println(deltaTime); // Выводим текущее время в консоль
        lastFrameTime = currentTime;   // Зачем мы это присваеваем currentTime'у ?
        controller.onDrawFrame(this, g, deltaTime);
        try{
            Thread.sleep(17); // Спит 17 мс
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        repaint();  // Перерисовывем все
    }

    public int getLeft() { return 0;}
    public int getRight() { return getWidth() - 1; }
    public int getTop() { return 0; }
    public int getBottom() { return getHeight() - 1; }
}