package ru.gb.catch_the_drop.lession_2_1;

import javax.swing.*;
import java.awt.*;

public class MainCircles extends JFrame {

    private static final int POS_X = 400; // Понятно
    private static final int POS_Y = 100; // Понятно
    private static final int WINDOW_WIDTH = 800; // Понятно
    private static final int WINDOW_HEIGHT = 600; // Понятно

    Sprite[] sprites = new Sprite[10]; // Понятно
    private int spritesCount;


    public static void main(String[] args) {
        new MainCircles();  // почему мы сделали именно так? можно было бы просто весь код класса MainCircles написать тут и все?
    }

    private MainCircles(){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); // Понятно
        setBounds(POS_X, POS_Y, WINDOW_WIDTH, WINDOW_HEIGHT); // Понятно
        setTitle("Circles"); // Понятно
        GameCanvas canvas = new GameCanvas(this); // Понятно
        initApplication(); // Вызываем метод, который рожает массивы с классом Ball
        add(canvas); // Добовляем канву
        setVisible(true); // Делаем окно видимым
    }


    private void addSprite(Sprite a) {    // что происходит тут ?
        sprites[spritesCount++] = a;
    }



    private void initApplication() {  // Метод для вызова Ball
        for (int i = 0; i < sprites.length; i++) {
            sprites[i] = new Ball();
        }
        addSprite(new RGB()); //Почему именно сюда мы его положили
    }

    public void onDrawFrame(GameCanvas canvas, Graphics g, float deltaTime) {
        update(canvas, deltaTime); // Обновили
        render(canvas, g); // Отрисовали
    }

    private void update (GameCanvas canvas, float deltaTime) { // Рисуем sprite
        for (int i = 0; i < sprites.length; i++) {
            sprites[i].update(canvas, deltaTime);  // Не особо понятно что это и от куда куда (после sprites[i]...)
        }
    }

    private void render(GameCanvas canvas, Graphics g) {  // Рендерем sprite
        for (int i = 0; i <sprites.length; i++) {
            sprites[i].render(canvas, g);     // тут тоже не понятно ...
        }
    }
}