package ru.gb.catch_the_drop.lession_2_1;

import java.awt.*;

public abstract class Sprite {

    protected float x; //Коррдинаты
    protected float y; //Коррдинаты
    protected float halfWidth; // Ширина
    protected float halfHeight; // Высота

    protected float getLeft() {
        return x - halfWidth;
    }
    //начлао не понятного
    protected void setLeft(float left) {
        x = left + halfWidth;
    } //Достаем       левую границу
    protected float getRight() {
        return x +halfWidth;
    }          //Устанавливаем левую границу
    protected void setRight (float right) {
        x =right - halfWidth;
    }
    protected float getTop() {
        return  y -halfHeight;
    }
    protected void setTop(float top) {
        y = top + halfHeight;
    }
    protected  float getBottom() {
        return  y + halfHeight;
    }
    protected void setBottom(float bottom) {
        y = bottom - halfHeight;
    }

    protected float getWidth() {
        return 2f * halfWidth;
    }
    protected float getHeight() {
        return 2f * halfHeight;
    }
    // конец непонятного


    void update (GameCanvas canvas, float deltaTime){}
    void render (GameCanvas canvas, Graphics g){}
}
